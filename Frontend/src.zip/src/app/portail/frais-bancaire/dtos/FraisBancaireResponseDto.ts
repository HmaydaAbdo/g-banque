import {Decimal} from "decimal.js";
import {Status} from "../../prefinancements/enums/Status";

export interface FraisBancaireResponseDto {
  id: number;
  libelle: string;
  observation: string;
  montant: Decimal;
  banqueId: number;
  banqueNom: string;
  dateEmission: string;
  dateValeur?: string;
  dateOperation?: string;
  status: Status;
}
